import './src/styles/global.scss';
import '@fontsource/sen/400.css';
import '@fontsource/sen/700.css';
import '@fontsource/sen/800.css';